import React from 'react';
import '../../App.css';
import Carousel from '../Carousel'
import OurBackground from '../OurBackground'
import Footer2 from '../Footer2';


export default function AboutUs() 
{
  return (
   
   <>
      <OurBackground/>
      <Carousel />  
      <Footer2/>
      
    </>
    
  );
  
}
