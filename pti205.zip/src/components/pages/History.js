import React from 'react';
import '../../App.css';
import Card from '../Card';
import HeroSections from '../HeroSections';
import Footer2 from '../Footer2';


export default function History() 
{
  return (
   
   <>
      <HeroSections/>
      <Card />
      <Footer2 />
      
      
    </>
    
  );
  
}
