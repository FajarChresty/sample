import React from 'react';
import '../../App.css';
import Cardss from '../Cardss';
import HeroSectionn from '../HeroSectionn';
import Footer2 from '../Footer2';

export default function Content() 

{
    return (
   
    <>
       <HeroSectionn/>
       <Cardss />
       <Footer2 />
       
       
     </>
     
   );
}