import React from 'react';
import '../App.css';
import './HeroSections.css';

function HeroSections() {
  return (
    <div className='heros-container'>
      <h1>Take a look at West Sumatran History</h1>
     </div>
  );
}

export default HeroSections;
